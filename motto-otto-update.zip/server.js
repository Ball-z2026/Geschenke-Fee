import express from 'express';
import sharp from 'sharp';
import fs from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';
import OpenAI from 'openai';
import { customAlphabet } from 'nanoid';
import { generateViaBallz, editViaBallz } from './ballz.js';
import { mottoStore, buildPrompt, printedTexts, cleanValue, stripChars, publicView, fillPrompt, sanitizeMotto, STYLE_KEYS, pickVariation, applyStyleOverrides, stylesForAdmin } from './mottos.js';
import { makeMaster, makePreview, makePdf, whiteCheck, normalizeUpload, signPreview, describeColors, cutout, edgeCheck } from './images.js';
import { ensureTemplates, makeMockup, templateReady, GARMENTS, COLORS } from './mockups.js';
import { accountStore, quotaCheck, bookDesign, accountView, sendLoginMail, normEmail, readCookies, setCookie, PLANS, GUEST_FREE } from './accounts.js';
import { setupStripe, createCheckout, createPortal, verifyWebhook, applyEvent } from './billing.js';
import { renderName, cleanNames, nameZonePrompt, MAX_NAMES } from './names.js';
import { researchMotto, researchPrompt } from './research.js';
import { gdrive } from './gdrive.js';
import { legalPages } from './rechtliches.js';

const env = {
  PORT: 8080,
  IMAGE_QUALITY: 'medium',
  QA_MODEL: 'gpt-5-mini',
  PUBLIC_BASE_URL: 'http://localhost:8080',
  MASTER_WIDTH: 4096,
  PREVIEW_TTL_DAYS: 0,
  LIMIT_GLOBAL_DAY: 1000,
  MAX_PARALLEL_JOBS: 2,
  CORS_ORIGINS: '',
  ACCOUNTS: 'off',            // 'on' = Anmeldung + Kontingent + Bezahlung greifen
  MAIL_FROM: 'otto@motto-otto.de',
  MAIL_FROM_NAME: 'Motto Otto',
  ...process.env
};
if (!env.BALLZ_MCP_URL) { console.error('BALLZ_MCP_URL fehlt'); process.exit(1); }

const HAS_LLM = !!env.OPENAI_API_KEY;
const openai = HAS_LLM ? new OpenAI({ apiKey: env.OPENAI_API_KEY }) : null;
const SIGN_SECRET = env.SIGN_SECRET || crypto.randomBytes(16).toString('hex');
const newId = customAlphabet('ABCDEFGHJKLMNPQRSTUVWXYZ23456789', 4);

const STORE = path.resolve('storage');
for (const d of ['mottos', 'uploads', 'masters', 'previews', 'jobs', 'mockups']) {
  await fs.mkdir(path.join(STORE, d), { recursive: true });
}
await ensureTemplates(STORE);

// Markenlogo (Otto mit Daumen hoch): einmal laden, freistellen, Favicon ableiten
const LOGO_SRC = env.LOGO_URL || 'https://mcp.markusassemacher.de/generated/0831727b-e5ec-444c-8ada-2cae60803eaa.png';
const LOGO_DIR = path.join(STORE, 'brand');
async function ensureLogo() {
  await fs.mkdir(LOGO_DIR, { recursive: true });
  const raw = path.join(LOGO_DIR, 'logo_raw.png');
  try { await fs.access(path.join(LOGO_DIR, 'favicon.png')); return; } catch (e) { /* bauen */ }
  let buf;
  try { buf = await fs.readFile(raw); }
  catch (e) {
    const r = await fetch(LOGO_SRC, { signal: AbortSignal.timeout(30000) });
    if (!r.ok) throw new Error('Logo HTTP ' + r.status);
    buf = Buffer.from(await r.arrayBuffer());
    await fs.writeFile(raw, buf);
  }
  const clear = await cutout(buf);
  await fs.writeFile(path.join(LOGO_DIR, 'logo.png'), await sharp(clear).trim().png().toBuffer());
  const sq = async (px) => sharp(clear).trim().resize({ width: px, height: px, fit: 'contain', background: { r: 0, g: 0, b: 0, alpha: 0 } }).png().toBuffer();
  await fs.writeFile(path.join(LOGO_DIR, 'favicon.png'), await sq(64));
  await fs.writeFile(path.join(LOGO_DIR, 'icon-180.png'), await sq(180));
  await fs.writeFile(path.join(LOGO_DIR, 'icon-512.png'), await sq(512));
  console.log('Logo bereit');
}
ensureLogo().catch(e => console.error('Logo:', e && e.message ? e.message : e));
const mottos = mottoStore(path.join(STORE, 'mottos'));
const accounts = accountStore(STORE, SIGN_SECRET);

// Stil-Prompts: Standard im Code, Aenderungen aus dem Backend auf dem Volume
const STYLES_FILE = path.join(STORE, 'styles.json');
try { applyStyleOverrides(JSON.parse(await fs.readFile(STYLES_FILE, 'utf8'))); } catch (e) { /* keine Aenderungen */ }
await accounts.ready();
const ACCOUNTS_ON = String(env.ACCOUNTS).toLowerCase() === 'on';
let stripeCfg = null;
try { stripeCfg = await setupStripe({ secretKey: env.STRIPE_SECRET_KEY, storeDir: STORE, baseUrl: env.PUBLIC_BASE_URL }); }
catch (e) { console.error('Stripe-Einrichtung fehlgeschlagen:', e && e.message ? e.message : e); }
const SECURE = String(env.PUBLIC_BASE_URL).startsWith('https');
const drive = gdrive({ clientId: env.GDRIVE_CLIENT_ID, clientSecret: env.GDRIVE_CLIENT_SECRET, storeDir: STORE, baseUrl: env.PUBLIC_BASE_URL, rootName: env.GDRIVE_ROOT || 'Motto Otto' });

// Druckdateien eines Designs zu Google Drive: Grunddatei plus je Name eine Datei
async function pushToDrive(designId) {
  const st = await drive.status();
  if (!st.connected) return { skipped: true };
  const j = await readJob(designId);
  const motto = (j && j.motto) || 'sonstige';
  const base = await fs.readFile(path.join(STORE, 'masters', `${designId}_PRINT_MASTER.png`));
  const parts = [motto, designId];
  const done = [];
  await drive.upload(parts, `${designId}_PRINT_MASTER.png`, base, 'image/png');
  done.push(`${designId}_PRINT_MASTER.png`);
  if (j && j.names && j.names.length) {
    for (let i = 0; i < j.names.length; i++) {
      const { buf, name } = await masterWithName(designId, i);
      const fn = `${designId}_${String(i + 1).padStart(2, '0')}_${name.replace(/[^A-Za-z0-9ÄÖÜäöüß]+/g, '-')}_PRINT.png`;
      await drive.upload(parts, fn, buf, 'image/png');
      done.push(fn);
    }
  }
  try {
    const info = { designId, motto, values: j && j.values, names: j && j.names, style: j && j.style, textile: j && j.textile, created: j && j.created };
    await drive.upload(parts, `${designId}_INFO.json`, Buffer.from(JSON.stringify(info, null, 2)), 'application/json');
  } catch (e) { /* Info ist Beiwerk */ }
  j.drive = { at: new Date().toISOString(), files: done };
  await fs.writeFile(path.join(STORE, 'jobs', `${designId}.json`), JSON.stringify(j, null, 2));
  return { files: done };
}

// Beim allerersten Start die vier Start-Mottos anlegen.
if ((await mottos.all()).length === 0) {
  try {
    const seed = JSON.parse(await fs.readFile(new URL('./seed.json', import.meta.url)));
    for (const m of seed) await mottos.save(m);
    console.log('Start-Mottos angelegt:', seed.length);
  } catch (e) {
    console.error('Start-Mottos konnten nicht angelegt werden:', e && e.message ? e.message : e);
  }
}

process.on('unhandledRejection', (e) => console.error('unhandledRejection:', e && e.message ? e.message : e));

// ---------- Tageszaehler als Kostenbremse ----------
const counter = { day: '', n: 0 };
const today = () => new Date().toISOString().slice(0, 10);
function overDailyLimit() {
  if (counter.day !== today()) { counter.day = today(); counter.n = 0; }
  if (counter.n >= +env.LIMIT_GLOBAL_DAY) return true;
  counter.n++;
  return false;
}

// ---------- Auftraege ----------
const jobs = new Map();
const queue = [];
let running = 0;

function enqueue(job) { queue.push(job); pump(); }
function pump() {
  while (running < +env.MAX_PARALLEL_JOBS && queue.length) {
    const job = queue.shift();
    running++;
    runJob(job)
      .catch(e => { job.status = 'error'; job.error = String(e && e.message ? e.message : e); console.error('Auftrag gescheitert:', job.jobId, job.error); })
      .finally(() => { running--; pump(); });
  }
}

async function textQA(png, want) {
  if (!HAS_LLM || !want.length) return { pass: true, skipped: true };
  const res = await openai.chat.completions.create({
    model: env.QA_MODEL,
    messages: [{
      role: 'user',
      content: [
        { type: 'text', text: `Read ALL text visible in this artwork. Answer ONLY with JSON: {"texts":[...],"pass":true|false,"reason":"..."}. pass is true only if each of these strings appears, case-insensitive and accents may be simplified: ${JSON.stringify(want)}, and no clearly misspelled words are present.` },
        { type: 'image_url', image_url: { url: 'data:image/png;base64,' + png.toString('base64') } }
      ]
    }]
  });
  const raw = String(res.choices[0].message.content || '').replace(/```json|```/g, '').trim();
  try { return JSON.parse(raw); } catch (e) { return { pass: true, reason: 'QA unlesbar', skipped: true }; }
}

async function runJob(job) {
  job.status = 'running';
  const { motto, values, uploadFile, style, colors, names = [], textile = 'dunkel' } = job.input;
  const personal = motto.fields.find(f => f.personal);

  const useReference = motto.upload.mode === 'reference' && uploadFile;
  let upload = null, logoColors = '';
  if (uploadFile) upload = await fs.readFile(path.join(STORE, 'uploads', uploadFile));
  if (upload && motto.upload.mode === 'exact') {
    try { logoColors = await describeColors(upload); } catch (e) { logoColors = ''; }
  }

  const variation = pickVariation(motto, { styled: !!(style && style !== 'standard') });
  // Motto-Recherche (Abi-Motto, Schulmotto): Wortspiel aufloesen, Bildwelt festlegen
  let research = '';
  if (motto.research && motto.researchField && values[motto.researchField]) {
    try {
      // "Bezug": worauf das Motto anspielt (z. B. ABItar -> Avatar). Wird nicht gemalt, nur recherchiert.
      const hintKey = motto.fields.some(f => f.key === 'bezug') ? 'bezug' : null;
      const hint = hintKey ? (values[hintKey] || '') : '';
      const ctx = Object.entries(values).filter(([k, v]) => k !== motto.researchField && k !== hintKey && v).map(([k, v]) => `${k}: ${v}`).join(', ');
      job.research = await researchMotto({ openai, model: env.QA_MODEL, storeDir: STORE, motto: values[motto.researchField], context: ctx, hint });
      research = researchPrompt(job.research);
    } catch (e) { console.error('Recherche gescheitert:', e && e.message ? e.message : e); }
  }

  const prompt = buildPrompt(motto, values, { style, colors, logoColors, variation, research, textile, nameZone: personal ? nameZonePrompt(motto.nameZone) : '' });
  job.promptHash = crypto.createHash('sha1').update(prompt).digest('hex').slice(0, 10);

  const want = printedTexts(motto, values);
  let png = null, qa = null, attempt = 0;

  while (attempt < 2) {
    attempt++;
    const gen = useReference
      ? await editViaBallz(env.BALLZ_MCP_URL, { prompt, size: motto.size, quality: env.IMAGE_QUALITY, imageBase64: upload.toString('base64'), mimeType: 'image/png' })
      : await generateViaBallz(env.BALLZ_MCP_URL, { prompt, size: motto.size, quality: env.IMAGE_QUALITY });
    png = gen.png;
    job.sourceUrl = gen.url;

    try {
      qa = await textQA(png, want);
    } catch (e) {
      console.error('textQA gescheitert:', e && e.message ? e.message : e);
      qa = { pass: true, reason: 'QA uebersprungen (Fehler)', skipped: true };
    }
    const white = await whiteCheck(png);
    if (white > 0.90) qa = { pass: false, reason: `fast leeres Bild (${(white * 100).toFixed(1)} % weiss)` };
    // Abgeschnitten? Motiv darf den Rand nicht beruehren - sonst noch ein Versuch
    if (qa.pass) {
      try {
        const e = await edgeCheck(await cutout(png));
        const worst = Math.max(e.top, e.bottom, e.left, e.right);
        if (worst > 0.08 && attempt < 2) qa = { pass: false, reason: `Motiv am Rand abgeschnitten (${Math.round(worst * 100)} % der Kante belegt)` };
      } catch (err) { /* Pruefung uebersprungen */ }
    }

    job.qa.push({ attempt, ...qa });
    if (qa.pass) break;
  }
  if (!qa.pass) { job.status = 'qa_failed'; return; }

  const designId = `MO-${motto.slug.toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 8)}-${new Date().toISOString().slice(0, 10).replace(/-/g, '')}-${newId()}`;

  const master = await makeMaster(png, {
    targetWidth: env.MASTER_WIDTH,
    logo: motto.upload.mode === 'exact' && upload ? upload : null,
    place: motto.upload.place,
    widthPct: motto.upload.widthPct
  });

  await fs.writeFile(path.join(STORE, 'masters', `${designId}_PRINT_MASTER.png`), master);
  const firstNamed = personal && names.length ? await renderName(master, names[0], { zone: motto.nameZone, font: motto.nameFont, textile }) : master;
  await fs.writeFile(path.join(STORE, 'previews', `${designId}.png`), await makePreview(firstNamed));
  job.names = names;
  job.textile = textile;

  const exp = Date.now() + 14 * 86400e3;
  const sig = signPreview(designId, exp, SIGN_SECRET);
  job.designId = designId;
  job.preview = `${env.PUBLIC_BASE_URL}/api/mo/preview/${designId}.png?exp=${exp}&sig=${sig}`;
  job.sig = { exp, sig };
  job.mockups = {};
  for (const g of Object.keys(GARMENTS)) {
    job.mockups[g] = { label: GARMENTS[g].label, view: GARMENTS[g].view };
    for (const c of COLORS) job.mockups[g][c] = `${env.PUBLIC_BASE_URL}/api/mo/mockup/${designId}/${g}/${c}.jpg?exp=${exp}&sig=${sig}`;
  }
  job.status = 'done';

  // Design dem Kunden bzw. Gast zuordnen und Verbrauch buchen
  try {
    if (job.who && job.who.userId) {
      const u = await accounts.byId(job.who.userId);
      if (u) await accounts.save(bookDesign(u, job.who.via, designId));
    } else if (job.who && job.who.guestId) {
      await accounts.guestAddDesign(job.who.guestId, designId);
    }
  } catch (e) { console.error('Buchung fehlgeschlagen:', e && e.message ? e.message : e); }

  setTimeout(() => pushToDrive(designId).catch(e => console.error('Drive:', e && e.message ? e.message : e)), 1500);

  await fs.writeFile(path.join(STORE, 'jobs', `${designId}.json`), JSON.stringify({
    designId, motto: motto.slug, values, style: style || 'standard', colors: colors || '', variation: variation || '', user: job.who && job.who.userId || null, via: job.who && job.who.via || null, names, nameZone: motto.nameZone, nameFont: motto.nameFont, textile, research: job.research || null, prompt, qa: job.qa, created: job.created, upload: uploadFile || null
  }, null, 2));
}

// ---------- App ----------
const app = express();
app.set('trust proxy', true);

const ALLOWED = String(env.CORS_ORIGINS).split(',').map(s => s.trim()).filter(Boolean);
app.use((req, res, next) => {
  const o = req.headers.origin;
  if (o && ALLOWED.includes(o)) {
    res.setHeader('Access-Control-Allow-Origin', o);
    res.setHeader('Vary', 'Origin');
    res.setHeader('Access-Control-Allow-Headers', 'content-type, x-admin-token');
    res.setHeader('Access-Control-Allow-Methods', 'GET,POST,PUT,DELETE,OPTIONS');
  }
  if (req.method === 'OPTIONS') return res.sendStatus(204);
  next();
});

// Stripe-Webhook braucht den rohen Body (Signatur) - deshalb vor dem JSON-Parser
app.post('/api/mo/stripe/webhook', express.raw({ type: '*/*', limit: '1mb' }), async (req, res) => {
  if (!stripeCfg || !env.STRIPE_SECRET_KEY) return res.status(503).end();
  const event = verifyWebhook(req.body.toString('utf8'), req.headers['stripe-signature'], stripeCfg.webhookSecret);
  if (!event) return res.status(400).json({ error: 'signatur' });
  try { await applyEvent(event, accounts, env.STRIPE_SECRET_KEY); res.json({ received: true }); }
  catch (e) { console.error('Webhook:', e && e.message ? e.message : e); res.status(500).json({ error: 'verarbeitung' }); }
});

app.use('/api/mo/upload', express.json({ limit: '9mb' }));
app.use(express.json({ limit: '256kb' }));

// ---------- Wer ist da? Gast-Cookie setzen, Sitzung lesen ----------
async function identify(req, res) {
  const c = readCookies(req);
  let guestId = /^g_[a-f0-9]{16}$/.test(c.mo_guest || '') ? c.mo_guest : null;
  if (!guestId) {
    guestId = 'g_' + crypto.randomBytes(8).toString('hex');
    if (res) setCookie(res, 'mo_guest', guestId, 365 * 86400, SECURE);
  }
  const userId = accounts.sessionUserId(c.mo_session);
  const user = userId ? await accounts.byId(userId) : null;
  const guest = user ? null : await accounts.guestGet(guestId);
  return { user, guestId, guest };
}

// ---------- Konto: Anmelde-Link, Sitzung, Kontostand ----------
app.post('/api/mo/login', async (req, res) => {
  const email = normEmail((req.body || {}).email);
  if (!email) return res.status(400).json({ error: 'email ungueltig' });
  const next = String((req.body || {}).next || '/konto');
  const safeNext = /^\/[a-z0-9\-\/_?=&]*$/i.test(next) ? next : '/konto';
  try {
    const token = await accounts.createLogin(email, safeNext);
    const link = `${env.PUBLIC_BASE_URL}/login?t=${token}`;
    const r = await sendLoginMail({ apiKey: env.BREVO_API_KEY, from: env.MAIL_FROM, fromName: env.MAIL_FROM_NAME, to: email, link, base: env.PUBLIC_BASE_URL });
    res.json({ ok: true, sent: !!r.sent });
  } catch (e) {
    console.error('Login-Mail:', e && e.message ? e.message : e);
    res.status(500).json({ error: 'mail' });
  }
});

app.get('/login', async (req, res) => {
  const l = await accounts.consumeLogin(req.query.t);
  if (!l) return res.status(400).send('<meta charset="utf-8"><p style="font-family:sans-serif;padding:30px">Der Anmelde-Link ist abgelaufen oder wurde schon benutzt. Bitte auf der Seite einen neuen anfordern.</p>');
  const who = await identify(req, res);
  let user = await accounts.getOrCreate(l.email);
  user.lastLogin = new Date().toISOString();
  user = await accounts.adoptGuest(user, who.guestId);
  await accounts.save(user);
  setCookie(res, 'mo_session', accounts.sessionValue(user.id), 180 * 86400, SECURE);
  res.redirect(l.next || '/konto');
});

app.post('/api/mo/logout', (req, res) => { setCookie(res, 'mo_session', '', 0, SECURE); res.json({ ok: true }); });

app.get('/api/mo/me', async (req, res) => {
  const who = await identify(req, res);
  if (!who.user) return res.json({ user: null, gast: { designs: who.guest.designs.length, frei: GUEST_FREE }, accounts: ACCOUNTS_ON, stripe: !!stripeCfg });
  const view = accountView(who.user);
  const exp = Date.now() + 14 * 86400e3;
  view.items = view.designs.map(id => ({
    designId: id,
    preview: `/api/mo/preview/${id}.png?exp=${exp}&sig=${signPreview(id, exp, SIGN_SECRET)}`,
    mockup: `/api/mo/mockup/${id}/tee/black.jpg?exp=${exp}&sig=${signPreview(id, exp, SIGN_SECRET)}`,
    hoodie: `/api/mo/mockup/${id}/hoodie/black.jpg?exp=${exp}&sig=${signPreview(id, exp, SIGN_SECRET)}`,
    zip: `/api/mo/mockup/${id}/zip/black.jpg?exp=${exp}&sig=${signPreview(id, exp, SIGN_SECRET)}`
  }));
  res.json({ user: view, accounts: ACCOUNTS_ON, stripe: !!stripeCfg });
});

// ---------- Bezahlen ----------
app.post('/api/mo/checkout', async (req, res) => {
  if (!stripeCfg || !env.STRIPE_SECRET_KEY) return res.status(503).json({ error: 'bezahlung nicht eingerichtet' });
  const who = await identify(req, res);
  if (!who.user) return res.status(401).json({ error: 'anmelden' });
  const kind = String((req.body || {}).kind || '');
  if (!['single', 'm100', 'm400'].includes(kind)) return res.status(400).json({ error: 'angebot ungueltig' });
  try {
    const url = await createCheckout({ secretKey: env.STRIPE_SECRET_KEY, cfg: stripeCfg, user: who.user, kind, quantity: (req.body || {}).quantity, baseUrl: env.PUBLIC_BASE_URL });
    res.json({ url });
  } catch (e) { console.error('Checkout:', e && e.message ? e.message : e); res.status(500).json({ error: 'checkout' }); }
});
app.post('/api/mo/portal', async (req, res) => {
  if (!stripeCfg) return res.status(503).json({ error: 'bezahlung nicht eingerichtet' });
  const who = await identify(req, res);
  if (!who.user) return res.status(401).json({ error: 'anmelden' });
  try { res.json({ url: await createPortal({ secretKey: env.STRIPE_SECRET_KEY, user: who.user, baseUrl: env.PUBLIC_BASE_URL }) }); }
  catch (e) { res.status(500).json({ error: 'portal' }); }
});

app.get('/konto', (req, res) => res.sendFile(path.resolve('konto.html')));

// Markenlogo und Icons
const brandFile = (name) => (req, res) => res.type('png').set('cache-control', 'public, max-age=86400').sendFile(path.join(LOGO_DIR, name), (e) => { if (e) res.status(404).end(); });
app.get('/logo.png', brandFile('logo.png'));
app.get('/favicon.png', brandFile('favicon.png'));
app.get('/favicon.ico', brandFile('favicon.png'));
app.get('/apple-touch-icon.png', brandFile('icon-180.png'));
app.get('/icon-512.png', brandFile('icon-512.png'));

// Rechtstexte
const LEGAL = legalPages(env);
app.get('/impressum', (req, res) => res.type('html').send(LEGAL.impressum));
app.get('/datenschutz', (req, res) => res.type('html').send(LEGAL.datenschutz));
app.get('/nutzungsbedingungen', (req, res) => res.type('html').send(LEGAL.agb));

// ---------- Kundenseite ----------
app.get('/api/mo/mottos', async (req, res) => {
  const list = (await mottos.all()).filter(m => m.active !== false).map(publicView);
  res.json({ mottos: list });
});

app.post('/api/mo/upload', async (req, res) => {
  const dataUrl = String((req.body && req.body.dataUrl) || '');
  const m = dataUrl.match(/^data:(image\/[a-z+.-]+);base64,(.+)$/i);
  if (!m) return res.status(400).json({ error: 'kein Bild' });
  const raw = Buffer.from(m[2], 'base64');
  if (raw.length > 8 * 1024 * 1024) return res.status(413).json({ error: 'zu gross' });
  try {
    const norm = await normalizeUpload(raw);
    const id = 'up_' + crypto.randomBytes(8).toString('hex') + '.png';
    await fs.writeFile(path.join(STORE, 'uploads', id), norm.png);
    res.json({ uploadId: id, width: norm.width, height: norm.height });
  } catch (e) {
    console.error('Upload gescheitert:', e && e.message ? e.message : e);
    res.status(400).json({ error: 'Bild nicht lesbar' });
  }
});

app.post('/api/mo/generate', async (req, res) => {
  const body = req.body || {};
  const motto = await mottos.get(body.motto);
  if (!motto || motto.active === false) return res.status(404).json({ error: 'motto unbekannt' });

  const values = {};
  let names = [];
  const bereinigt = []; // was wir stillschweigend geaendert haben (Emojis, Sonderzeichen)
  const personal = motto.fields.find(f => f.personal);
  for (const f of motto.fields) {
    const raw = (body.values || {})[f.key];
    if (f.personal) {
      // Namensliste: kommt als Array oder Zeilen; wird NICHT von der KI gemalt
      const cn = cleanNames(Array.isArray(body.names) && body.names.length ? body.names : raw, f.max);
      for (const c of cn.changed) bereinigt.push({ feld: f.label, vorher: c.vorher, nachher: c.nachher });
      names = cn.names;
      if (!names.length && f.required) return res.status(400).json({ error: 'feld fehlt', feld: f.label });
      values[f.key] = '';
      continue;
    }
    if (f.type === 'select') {
      const v = String(raw || '').trim();
      if (v && !f.options.includes(v)) return res.status(400).json({ error: 'auswahl ungueltig', feld: f.label });
      if (!v && f.required) return res.status(400).json({ error: 'feld fehlt', feld: f.label });
      values[f.key] = v;
      continue;
    }
    const v = cleanValue(raw, f.max);
    if (v === null) return res.status(400).json({ error: 'zeichen nicht erlaubt', feld: f.label });
    if (!v && f.required) return res.status(400).json({ error: 'feld fehlt', feld: f.label });
    const orig = String(raw || '').replace(/\s+/g, ' ').trim();
    if (orig && v !== orig) bereinigt.push({ feld: f.label, vorher: orig, nachher: v });
    values[f.key] = v;
  }

  // Helles oder dunkles Textil - bestimmt Druckregeln, Namensfarbe und Standard-Mockup
  const textile = String(body.textile || 'dunkel') === 'hell' ? 'hell' : 'dunkel';

  let uploadFile = null;
  if (motto.upload.mode !== 'off') {
    const id = String(body.uploadId || '');
    if (id) {
      if (!/^up_[a-f0-9]{16}\.png$/.test(id)) return res.status(400).json({ error: 'upload ungueltig' });
      try { await fs.access(path.join(STORE, 'uploads', id)); uploadFile = id; }
      catch (e) { return res.status(400).json({ error: 'upload nicht gefunden' }); }
    } else if (motto.upload.required) {
      return res.status(400).json({ error: 'upload fehlt' });
    }
  }

  // Stil und Lieblingsfarben - auf jeder Motto-Seite waehlbar, sofern im Motto nicht abgeschaltet
  let style = String(body.style || 'standard');
  if (!STYLE_KEYS.includes(style)) return res.status(400).json({ error: 'stil ungueltig' });
  if (motto.styleChoice === false) style = 'standard';
  let colors = cleanValue(body.colors, 40);
  if (colors === null) colors = '';
  if (motto.colorChoice === false) colors = '';

  if (overDailyLimit()) return res.status(429).json({ error: 'tageslimit' });

  // Wer ist das? Gast-Cookie oder angemeldeter Kunde. Kontingent greift nur bei ACCOUNTS=on.
  const who = await identify(req, res);
  let via = 'guest';
  if (ACCOUNTS_ON) {
    const q = quotaCheck(who.user, who.guest);
    if (!q.ok) {
      if (q.reason === 'login') return res.status(401).json({ error: 'anmelden', frei: GUEST_FREE });
      return res.status(402).json({ error: 'bezahlen', konto: accountView(who.user) });
    }
    via = q.via;
  }

  const jobId = 'mo_' + crypto.randomBytes(8).toString('hex');
  const job = { jobId, status: 'queued', qa: [], created: new Date().toISOString(), input: { motto, values, uploadFile, style, colors, names, textile }, who: { userId: who.user ? who.user.id : null, guestId: who.guestId, via } };
  jobs.set(jobId, job);
  enqueue(job);
  res.json({ jobId, eta: 50 + queue.length * 45, bereinigt, names });
});

app.get('/api/mo/job/:id', (req, res) => {
  const j = jobs.get(req.params.id);
  if (!j) return res.status(404).json({ error: 'auftrag unbekannt' });
  res.json({
    status: j.status, designId: j.designId, preview: j.preview, mockups: j.mockups, error: j.error, names: j.names || [], sig: j.sig || null, textile: j.textile || 'dunkel',
    qa: j.status === 'qa_failed' ? (j.qa.at(-1) || {}).reason : undefined
  });
});

// Druckdatei eines Designs, wahlweise mit dem n-ten Namen der Namensliste (Cache in mockups/)
async function readJob(designId) {
  try { return JSON.parse(await fs.readFile(path.join(STORE, 'jobs', `${designId}.json`), 'utf8')); } catch (e) { return null; }
}
async function masterWithName(designId, n) {
  const base = path.join(STORE, 'masters', `${designId}_PRINT_MASTER.png`);
  const idx = Number.isInteger(+n) && +n >= 0 ? +n : -1;
  if (idx < 0) return { buf: await fs.readFile(base), name: null };
  const j = await readJob(designId);
  const name = j && j.names && j.names[idx];
  if (!name) return { buf: await fs.readFile(base), name: null };
  const cached = path.join(STORE, 'mockups', `named_${designId}_${idx}.png`);
  try { return { buf: await fs.readFile(cached), name }; } catch (e) { /* bauen */ }
  const out = await renderName(await fs.readFile(base), name, { zone: j.nameZone, font: j.nameFont, textile: j.textile });
  await fs.writeFile(cached, out);
  return { buf: out, name };
}

app.get('/api/mo/preview/:file', async (req, res) => {
  const designId = String(req.params.file).replace(/\.png$/, '').replace(/[^A-Za-z0-9_-]/g, '');
  const { exp, sig, n } = req.query;
  if (!exp || +exp < Date.now() || signPreview(designId, exp, SIGN_SECRET) !== sig) return res.status(403).end();
  try {
    if (n !== undefined) {
      const cached = path.join(STORE, 'mockups', `namedprev_${designId}_${+n}.png`);
      try { return res.type('png').send(await fs.readFile(cached)); } catch (e) { /* bauen */ }
      const { buf } = await masterWithName(designId, n);
      const prev = await makePreview(buf);
      await fs.writeFile(cached, prev);
      return res.type('png').send(prev);
    }
    res.type('png').send(await fs.readFile(path.join(STORE, 'previews', `${designId}.png`)));
  } catch (e) { res.status(404).end(); }
});

// Namen nachtraeglich aendern - das Design bleibt, nur die Namen werden neu gesetzt
app.post('/api/mo/names', async (req, res) => {
  const designId = String((req.body || {}).designId || '').replace(/[^A-Za-z0-9_-]/g, '');
  const j = await readJob(designId);
  if (!j) return res.status(404).json({ error: 'unbekanntes Design' });
  const who = await identify(req, res);
  const mine = (who.user && who.user.designs.includes(designId)) || (who.guest && who.guest.designs.includes(designId));
  if (!mine) return res.status(403).json({ error: 'nicht dein Design' });
  const motto = await mottos.get(j.motto);
  const personal = motto && motto.fields.find(f => f.personal);
  if (!personal) return res.status(400).json({ error: 'motto ohne Namensliste' });
  const cn = cleanNames((req.body || {}).names, personal.max);
  j.names = cn.names;
  await fs.writeFile(path.join(STORE, 'jobs', `${designId}.json`), JSON.stringify(j, null, 2));
  // alte Namens-Caches wegwerfen
  try { for (const f of await fs.readdir(path.join(STORE, 'mockups'))) if (f.includes(`_${designId}_`) && /^named/.test(f)) await fs.rm(path.join(STORE, 'mockups', f), { force: true }); } catch (e) { /* egal */ }
  const exp = Date.now() + 14 * 86400e3;
  res.json({ names: j.names, bereinigt: cn.changed, sig: { exp, sig: signPreview(designId, exp, SIGN_SECRET) } });
});

// Mockup: Druckdatei auf T-Shirt, Hoodie oder Zip-Jacke gelegt. Wird beim ersten Abruf gebaut und gemerkt.
app.get('/api/mo/mockup/:designId/:garment/:file', async (req, res) => {
  const designId = String(req.params.designId).replace(/[^A-Za-z0-9_-]/g, '');
  const garment = String(req.params.garment);
  const color = String(req.params.file).replace(/\.jpg$/i, '');
  const { exp, sig } = req.query;
  if (!exp || +exp < Date.now() || signPreview(designId, exp, SIGN_SECRET) !== sig) return res.status(403).end();
  if (!GARMENTS[garment] || !COLORS.includes(color)) return res.status(404).end();
  const n = req.query.n !== undefined && Number.isInteger(+req.query.n) ? +req.query.n : -1;
  const cached = path.join(STORE, 'mockups', n >= 0 ? `named_${designId}_${n}_${garment}_${color}.jpg` : `${designId}_${garment}_${color}.jpg`);
  try { return res.type('jpeg').send(await fs.readFile(cached)); } catch (e) { /* noch nicht gebaut */ }
  if (!(await templateReady(garment, color))) return res.status(503).json({ error: 'vorlage fehlt' });
  try {
    const master = n >= 0 ? (await masterWithName(designId, n)).buf : await fs.readFile(path.join(STORE, 'masters', `${designId}_PRINT_MASTER.png`));
    const jpg = await makeMockup(master, garment, color, true);
    await fs.writeFile(cached, jpg);
    res.type('jpeg').send(jpg);
  } catch (e) {
    console.error('Mockup gescheitert:', e && e.message ? e.message : e);
    res.status(404).end();
  }
});

// ---------- Druckdateien ----------
const masterGuard = (req, res) => {
  const t = req.query.token || req.get('x-master-token');
  if (!env.MASTER_TOKEN || t !== env.MASTER_TOKEN) { res.status(403).json({ error: 'kein Zugang' }); return false; }
  return true;
};

app.get('/api/mo/masters', async (req, res) => {
  if (!masterGuard(req, res)) return;
  const dir = path.join(STORE, 'masters');
  try {
    const files = await fs.readdir(dir);
    const out = [];
    for (const f of files) {
      const st = await fs.stat(path.join(dir, f));
      const designId = f.replace('_PRINT_MASTER.png', '');
      const j = await readJob(designId);
      out.push({ file: f, designId, bytes: st.size, at: st.mtime.toISOString(), names: j && j.names && j.names.length ? j.names : undefined, motto: j && j.motto, values: j && j.values });
    }
    out.sort((a, b) => a.at < b.at ? 1 : -1);
    res.json({ count: out.length, masters: out.slice(0, 300) });
  } catch (e) { res.status(500).json({ error: 'lesen gescheitert' }); }
});

app.get('/api/mo/master/:file', async (req, res) => {
  if (!masterGuard(req, res)) return;
  const wantPdf = /\.pdf$/i.test(req.params.file);
  const designId = String(req.params.file).replace(/\.(png|pdf)$/i, '').replace(/[^A-Za-z0-9_-]/g, '');
  try {
    const { buf, name } = await masterWithName(designId, req.query.n);
    const suffix = name ? '_' + name.replace(/[^A-Za-z0-9]+/g, '-') : '';
    if (wantPdf) {
      const pdf = await makePdf(buf, req.query.dpi);
      return res.type('pdf').set('content-disposition', `attachment; filename="${designId}${suffix}_PRINT.pdf"`).send(pdf);
    }
    res.type('png').set('content-disposition', `attachment; filename="${designId}${suffix}_PRINT_MASTER.png"`).send(buf);
  } catch (e) { res.status(404).json({ error: 'unbekanntes Design' }); }
});

// Druckdateien-Uebersicht fuer die Produktion: alle Designs, je Name eine Datei
app.get('/druck', async (req, res) => {
  if (!masterGuard(req, res)) return;
  const token = req.query.token;
  const dir = path.join(STORE, 'masters');
  let files = [];
  try { files = (await fs.readdir(dir)).filter(f => f.endsWith('_PRINT_MASTER.png')); } catch (e) { /* leer */ }
  const items = [];
  for (const f of files) {
    const designId = f.replace('_PRINT_MASTER.png', '');
    const st = await fs.stat(path.join(dir, f));
    const j = await readJob(designId);
    items.push({ designId, at: st.mtime, j });
  }
  items.sort((a, b) => b.at - a.at);
  const exp = Date.now() + 86400e3;
  const rows = items.map(({ designId, at, j }) => {
    const sig = signPreview(designId, exp, SIGN_SECRET);
    const vals = j && j.values ? Object.values(j.values).filter(Boolean).join(' · ') : '';
    const names = j && j.names && j.names.length ? j.names : null;
    const link = (n, label) => `<a href="/api/mo/master/${designId}.png?token=${token}${n >= 0 ? '&n=' + n : ''}">${escHtml(label)} PNG</a> <a href="/api/mo/master/${designId}.pdf?token=${token}${n >= 0 ? '&n=' + n : ''}">PDF</a>`;
    const nameLinks = names ? '<div class="names">' + names.map((n, i) => `<span>${escHtml(n)}: ${link(i, '')}</span>`).join('') + '</div>' : '';
    return `<div class="row">
      <a href="/api/mo/preview/${designId}.png?exp=${exp}&sig=${sig}" target="_blank"><img src="/api/mo/mockup/${designId}/tee/${j && j.textile === 'hell' ? 'white' : 'black'}.jpg?exp=${exp}&sig=${sig}" loading="lazy"></a>
      <div class="info">
        <b>${escHtml(j && j.motto || '')}</b> <span class="id">${escHtml(designId)}</span> <span class="t">${at.toLocaleString('de-DE')}</span>
        <div class="v">${escHtml(vals)}${j && j.style && j.style !== 'standard' ? ' · Stil: ' + escHtml(j.style) : ''}${j && j.textile === 'hell' ? ' · helles Textil' : ''}</div>
        <div class="dl">${names ? 'Ohne Namen: ' : ''}${link(-1, 'Druckdatei')} <small>4096 px breit, transparent · PDF 300 dpi</small></div>
        ${nameLinks}
      </div></div>`;
  }).join('');
  res.type('html').send(`<!doctype html><html lang="de"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Motto Otto · Druckdateien</title>
<style>body{margin:0;background:#14131a;color:#f4f2f7;font-family:system-ui,sans-serif;font-size:15px}.wrap{max-width:1000px;margin:0 auto;padding:24px 16px}h1{font-size:22px}h1 span{color:#ffc542}
.row{display:flex;gap:16px;background:#1d1c25;border:1px solid #35323f;border-radius:10px;padding:12px;margin-bottom:12px}.row img{width:140px;height:140px;object-fit:cover;border-radius:8px;background:#26242f}
.info{flex:1;min-width:0}.id{font-family:ui-monospace,monospace;font-size:12px;color:#ffc542}.t{color:#8b8598;font-size:12px}.v{color:#b6b1c2;margin:4px 0 8px}
a{color:#ffc542;text-decoration:none;font-weight:700}a:hover{text-decoration:underline}.dl small{color:#8b8598;font-weight:400;margin-left:8px}
.names{display:flex;flex-wrap:wrap;gap:6px 14px;margin-top:8px;font-size:13.5px}.names span{background:#26242f;border-radius:6px;padding:4px 8px}</style>
<link rel="icon" href="/favicon.png"><div class="wrap"><h1 style="display:flex;align-items:center;gap:12px"><img src="/logo.png" alt="" style="height:52px">Motto <span>Otto</span> · Druckdateien (${items.length})</h1><p style="color:#8b8598">Neueste zuerst. PNG = 4096 px breit, freigestellt; PDF im echten Maß bei 300 dpi (<code>&amp;dpi=150</code> für größer). Bei Namenslisten gibt es je Name eine eigene Datei.</p>${rows}</div></html>`);
});

// ---------- Backend ----------
const adminGuard = (req, res, next) => {
  const t = req.query.token || req.get('x-admin-token');
  if (!env.ADMIN_TOKEN || t !== env.ADMIN_TOKEN) return res.status(403).json({ error: 'kein Zugang' });
  next();
};

app.get('/api/admin/mottos', adminGuard, async (req, res) => res.json({ mottos: await mottos.all() }));

app.put('/api/admin/mottos/:slug', adminGuard, async (req, res) => {
  try {
    const saved = await mottos.save({ ...(req.body || {}), slug: req.params.slug });
    res.json({ motto: saved });
  } catch (e) { res.status(400).json({ error: String(e.message || e) }); }
});

app.post('/api/admin/mottos', adminGuard, async (req, res) => {
  try {
    const saved = await mottos.save(req.body || {});
    res.json({ motto: saved });
  } catch (e) { res.status(400).json({ error: String(e.message || e) }); }
});

app.delete('/api/admin/mottos/:slug', adminGuard, async (req, res) => {
  await mottos.remove(req.params.slug);
  res.json({ ok: true });
});

// Prompt-Vorschau: zeigt, was wirklich beim Bildgenerator ankommt - kostet nichts.
app.post('/api/admin/prompt-vorschau', adminGuard, (req, res) => {
  try {
    const m = sanitizeMotto((req.body || {}).motto);
    const values = {};
    for (const f of m.fields) {
      const given = ((req.body || {}).values || {})[f.key];
      values[f.key] = given !== undefined && given !== '' ? String(given) : (f.type === 'select' ? (f.options[0] || '') : (f.placeholder || f.label).replace(/^z\. ?B\. /, ''));
    }
    const b = req.body || {};
    res.json({ prompt: buildPrompt(m, values, { style: b.style, colors: b.colors, variation: pickVariation(m) }), values });
  } catch (e) { res.status(400).json({ error: String(e.message || e) }); }
});

// ---------- Seiten ----------
const escHtml = (v) => String(v == null ? '' : v).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);
const readTpl = (name) => fs.readFile(path.resolve(name), 'utf8');

// Uebersicht: eine Kachel je Motto
app.get('/', async (req, res) => {
  const list = (await mottos.all()).filter(m => m.active !== false);
  const cards = list.map(m => {
    const c = m.accent || '#ffc542';
    const pic = m.sample
      ? `<img src="/api/mo/sample/${escHtml(m.slug)}.jpg?v=${escHtml(m.sample)}" alt="${escHtml(m.name)}" loading="lazy" onerror="this.remove()">`
      : '';
    return `<a class="card" href="/m/${escHtml(m.slug)}" style="--c:${escHtml(c)}">
      <div class="pic"><div class="ph">${escHtml(m.name.slice(0, 1))}</div>${pic}</div>
      <div class="body"><h3>${escHtml(m.name)}</h3><p>${escHtml(m.intro || '')}</p><span class="go">Design machen</span></div>
    </a>`;
  }).join('\n');
  res.type('html').send((await readTpl('home.html')).replace('<!--MOTTOS-->', cards));
});

// Eigene Seite je Motto
app.get('/m/:slug', async (req, res) => {
  const m = await mottos.get(req.params.slug);
  if (!m || m.active === false) return res.redirect('/');
  const title = `${m.name} – Motto Otto`;
  const desc = m.intro || `${m.name}-Shirt in einer Minute gestaltet.`;
  const sample = m.sample ? `/api/mo/sample/${m.slug}.jpg?v=${encodeURIComponent(m.sample)}` : '';
  const html = (await readTpl('motto.html'))
    .replace(/__TITLE__/g, escHtml(title))
    .replace(/__DESC__/g, escHtml(desc))
    .replace(/__OG__/g, escHtml(sample ? env.PUBLIC_BASE_URL + sample : ''))
    .replace(/__ACCENT__/g, escHtml(m.accent || '#ffc542'))
    .replace(/__HEADLINE__/g, escHtml(m.headline || m.name))
    .replace(/__TEXT__/g, escHtml(m.text || m.intro || ''))
    .replace(/__SAMPLE__/g, escHtml(sample))
    .replace('__MOTTO_JSON__', JSON.stringify(publicView(m)).replace(/</g, '\\u003c'));
  res.type('html').send(html);
});

// Beispielbild je Motto: das T-Shirt-Mockup eines gespeicherten Designs, ohne Wasserzeichen
app.get('/api/mo/sample/:file', async (req, res) => {
  const slug = String(req.params.file).replace(/\.jpg$/i, '');
  const m = await mottos.get(slug);
  if (!m || !m.sample) return res.status(404).end();
  const cached = path.join(STORE, 'mockups', `sample_${m.slug}_${m.sample}.jpg`);
  try { return res.type('jpeg').set('cache-control', 'public, max-age=3600').send(await fs.readFile(cached)); } catch (e) { /* bauen */ }
  try {
    const master = await fs.readFile(path.join(STORE, 'masters', `${m.sample}_PRINT_MASTER.png`));
    const jpg = await makeMockup(master, 'tee', 'black', false);
    await fs.writeFile(cached, jpg);
    res.type('jpeg').set('cache-control', 'public, max-age=3600').send(jpg);
  } catch (e) { res.status(404).end(); }
});

app.get('/alle', (req, res) => res.sendFile(path.resolve('index.html')));
app.get('/admin', (req, res) => res.sendFile(path.resolve('admin.html')));

// Letzte Entwuerfe fuers Backend
app.get('/api/admin/jobs', adminGuard, async (req, res) => {
  const dir = path.join(STORE, 'jobs');
  try {
    const files = (await fs.readdir(dir)).filter(f => f.endsWith('.json'));
    const withTime = [];
    for (const f of files) { const st = await fs.stat(path.join(dir, f)); withTime.push({ f, t: st.mtimeMs }); }
    withTime.sort((a, b) => b.t - a.t);
    const out = [];
    for (const { f } of withTime.slice(0, 60)) {
      try {
        const j = JSON.parse(await fs.readFile(path.join(dir, f), 'utf8'));
        const exp = Date.now() + 86400e3;
        out.push({ designId: j.designId, motto: j.motto, values: j.values, style: j.style || 'standard', colors: j.colors || '', variation: j.variation || '', names: j.names || [], textile: j.textile || 'dunkel', research: j.research ? { pun_source: j.research.pun_source, theme: j.research.theme } : null, created: j.created, qa: (j.qa || []).at(-1),
          preview: `/api/mo/preview/${j.designId}.png?exp=${exp}&sig=${signPreview(j.designId, exp, SIGN_SECRET)}`,
          mockup: `/api/mo/mockup/${j.designId}/tee/black.jpg?exp=${exp}&sig=${signPreview(j.designId, exp, SIGN_SECRET)}` });
      } catch (e) { /* ueberspringen */ }
    }
    res.json({ jobs: out });
  } catch (e) { res.json({ jobs: [] }); }
});
// Google Drive: verbinden (OAuth, der Chef klickt selbst), Status, alles nachladen
app.get('/api/admin/gdrive/status', adminGuard, async (req, res) => res.json(await drive.status()));
app.get('/api/admin/gdrive/connect', adminGuard, (req, res) => {
  if (!drive.enabled()) return res.status(503).send('GDRIVE_CLIENT_ID / GDRIVE_CLIENT_SECRET fehlen in Railway');
  res.redirect(drive.authUrl());
});
app.get('/api/admin/gdrive/callback', async (req, res) => {
  try { const st = await drive.connect(String(req.query.code || '')); res.redirect('/admin?gdrive=' + encodeURIComponent(st.email || 'ok')); }
  catch (e) { res.status(400).send('Google Drive konnte nicht verbunden werden: ' + escHtml(String(e.message || e))); }
});
app.post('/api/admin/gdrive/disconnect', adminGuard, async (req, res) => { await drive.disconnect(); res.json({ ok: true }); });
app.post('/api/admin/gdrive/push', adminGuard, async (req, res) => {
  const one = String((req.body || {}).designId || '').replace(/[^A-Za-z0-9_-]/g, '');
  let ids = [];
  if (one) ids = [one];
  else {
    try { ids = (await fs.readdir(path.join(STORE, 'masters'))).filter(f => f.endsWith('_PRINT_MASTER.png')).map(f => f.replace('_PRINT_MASTER.png', '')); } catch (e) { ids = []; }
    if (!(req.body || {}).all) { const out = []; for (const id of ids) { const j = await readJob(id); if (!(j && j.drive)) out.push(id); } ids = out; }
  }
  res.json({ queued: ids.length });
  (async () => { for (const id of ids) { try { await pushToDrive(id); } catch (e) { console.error('Drive nachladen', id, e && e.message ? e.message : e); } } })();
});

// Stile lesen/aendern
app.get('/api/admin/styles', adminGuard, (req, res) => res.json({ styles: stylesForAdmin() }));
app.put('/api/admin/styles', adminGuard, async (req, res) => {
  const list = Array.isArray((req.body || {}).styles) ? req.body.styles : [];
  const over = {};
  for (const st of list) if (st && STYLE_KEYS.includes(st.key)) over[st.key] = { label: st.label, desc: st.desc, text: st.text, off: !!st.off };
  applyStyleOverrides(over);
  await fs.writeFile(STYLES_FILE, JSON.stringify(over, null, 2));
  res.json({ styles: stylesForAdmin() });
});

app.get('/api/admin/users', adminGuard, async (req, res) => {
  const list = await accounts.all();
  res.json({ users: list.map(u => ({ id: u.id, email: u.email, created: u.created, lastLogin: u.lastLogin, designs: u.designs.length, freeUsed: u.freeUsed, credits: u.credits, plan: u.plan, planUsed: u.planUsed, planPeriodEnd: u.planPeriodEnd ? new Date(u.planPeriodEnd).toISOString() : null })) });
});
app.post('/api/admin/users/:id/credits', adminGuard, async (req, res) => {
  const u = await accounts.byId(req.params.id);
  if (!u) return res.status(404).json({ error: 'unbekannt' });
  u.credits = Math.max(0, u.credits + (+(req.body || {}).delta || 0));
  res.json({ user: await accounts.save(u) });
});

app.get('/health', async (req, res) => res.json({ ok: true, llm: HAS_LLM, mottos: (await mottos.all()).length, heute: counter.n, konten: ACCOUNTS_ON, stripe: !!stripeCfg, mail: !!env.BREVO_API_KEY, drive: (await drive.status()).connected }));

// ---------- Aufraeumen, nur wenn eine Frist gesetzt ist ----------
if (+env.PREVIEW_TTL_DAYS > 0) {
  setInterval(async () => {
    const ttl = +env.PREVIEW_TTL_DAYS * 86400e3;
    try {
      for (const f of await fs.readdir(path.join(STORE, 'previews'))) {
        const p = path.join(STORE, 'previews', f);
        const st = await fs.stat(p);
        if (Date.now() - st.mtimeMs > ttl) {
          await fs.rm(p, { force: true });
          await fs.rm(path.join(STORE, 'masters', `${f.replace('.png', '')}_PRINT_MASTER.png`), { force: true });
        }
      }
    } catch (e) { console.error('Aufraeumen:', e && e.message ? e.message : e); }
  }, 6 * 3600e3);
}

app.listen(+env.PORT, () => console.log(`motto-otto auf :${env.PORT} - Backend: /admin - LLM: ${HAS_LLM ? 'an' : 'aus'}`));
