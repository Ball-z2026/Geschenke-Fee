import fs from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';

// Motto-Recherche (Abi-Motto, Schulmotto): Wortspiel aufloesen, Quelle nachschlagen, Bildwelt festlegen.
// Analog zur Orts-Recherche bei kiezfashion: erst Fakten holen, dann daraus den Prompt bauen.

const SYS = `You are the art director of a German T-shirt print shop. Students send you their class motto (Abi-Motto / Schulmotto).
Most mottos are puns that hide the word ABI (or a year, school type or class) inside a known word, title, brand, film, game, place or phrase - for example "ABIkropolis" (Akropolis), "HABIbi", "ABInauten" (astronauts), "ABIos Amigos", "KABIverse", "ABIgail", "ABI Vegas", "FABIulous".
Your job: explain the pun, name the source it plays on, and define a picture for a shirt print.
Answer ONLY with JSON:
{
 "pun_source": "the word/title/thing the motto plays on, or null if it is not a pun",
 "wiki_title": "German Wikipedia article title for the source, or null",
 "theme": "one sentence: what world the design lives in",
 "motifs": ["4-7 concrete visual elements that clearly evoke the source, most important first"],
 "palette": "3-4 colors that fit the source, light lettering-friendly",
 "lettering": "what kind of lettering fits (e.g. Greek-temple capitals, space-age chrome, neon script)",
 "avoid": ["things not to draw: real logos, trademarks, recognizable persons, copyrighted characters"],
 "tagline": "an optional short German secondary line that fits the pun, or null"
}
Rules: never suggest drawing a real trademark, brand logo or a copyrighted character - describe the style and generic elements instead (a superhero silhouette, not a specific one). Keep motifs printable as bold flat vector shapes.`;

async function wikiSummary(title) {
  if (!title) return null;
  try {
    const r = await fetch('https://de.wikipedia.org/api/rest_v1/page/summary/' + encodeURIComponent(String(title).replace(/ /g, '_')), {
      headers: { 'user-agent': 'motto-otto/1.0 (kontakt@motto-otto.de)' }, signal: AbortSignal.timeout(10000)
    });
    if (!r.ok) return null;
    const j = await r.json();
    if (!j.extract) return null;
    return { title: j.title, extract: String(j.extract).slice(0, 700), url: j.content_urls && j.content_urls.desktop ? j.content_urls.desktop.page : null };
  } catch (e) { return null; }
}

export async function researchMotto({ openai, model, storeDir, motto, context, hint }) {
  const key = crypto.createHash('sha1').update(String(motto).toLowerCase().trim() + '|' + String(hint || '') + '|' + String(context || '')).digest('hex').slice(0, 16);
  const dir = path.join(storeDir, 'research');
  await fs.mkdir(dir, { recursive: true });
  const file = path.join(dir, key + '.json');
  try { return JSON.parse(await fs.readFile(file, 'utf8')); } catch (e) { /* neu */ }
  if (!openai) return null;

  const ask = async (extra) => {
    const res = await openai.chat.completions.create({
      model,
      messages: [
        { role: 'system', content: SYS },
        { role: 'user', content: `Motto: "${motto}"${hint ? `\nThe students explain what the motto refers to: "${hint}". Treat this as the definitive pun source - build the whole picture world around it.` : ''}${context ? `\nContext: ${context}` : ''}${extra ? `\n${extra}` : ''}` }
      ]
    });
    const raw = String(res.choices[0].message.content || '').replace(/```json|```/g, '').trim();
    return JSON.parse(raw);
  };

  let card = await ask('');
  // Quelle nachschlagen und dem Modell zur Korrektur zeigen
  const wiki = await wikiSummary(card.wiki_title || card.pun_source);
  if (wiki) {
    try {
      card = await ask(`Wikipedia says about "${wiki.title}": ${wiki.extract}\nRefine motifs and palette so they match this source precisely. Keep the JSON format.`);
    } catch (e) { /* erste Karte behalten */ }
    card.wiki = wiki;
  }
  card.motto = motto;
  if (hint) card.hint = hint;
  card.created = new Date().toISOString();
  await fs.writeFile(file, JSON.stringify(card, null, 2));
  return card;
}

// Text fuer den Prompt
export function researchPrompt(card) {
  if (!card) return '';
  const lines = [`THEME RESEARCH for the motto "${card.motto}" (use this to build the picture):`];
  if (card.hint) lines.push(`- The students say the motto refers to: ${card.hint}`);
  if (card.pun_source) lines.push(`- The motto is a pun on: ${card.pun_source}${card.wiki ? ` - ${card.wiki.extract.slice(0, 180)}` : ''}`);
  if (card.theme) lines.push(`- World of the design: ${card.theme}`);
  if (card.motifs && card.motifs.length) lines.push(`- Visual elements to use (most important first): ${card.motifs.slice(0, 6).join('; ')}`);
  if (card.palette) lines.push(`- Palette: ${card.palette}`);
  if (card.lettering) lines.push(`- Lettering: ${card.lettering}`);
  if (card.avoid && card.avoid.length) lines.push(`- Do not draw: ${card.avoid.join('; ')}`);
  lines.push('- The motto itself must be written exactly as given, letter by letter, including its unusual capitalization.');
  return lines.join('\n');
}
