// Rechtstexte: Datenschutz, Nutzungsbedingungen, Impressum. Firmendaten kommen aus Umgebungsvariablen,
// damit sie ohne Code-Aenderung gepflegt werden koennen (IMPRESSUM_* in Railway).
export function legalPages(env) {
  const firma = env.IMPRESSUM_FIRMA || '[Firma / Inhaber – bitte in Railway als IMPRESSUM_FIRMA eintragen]';
  const anschrift = env.IMPRESSUM_ANSCHRIFT || '[Straße, PLZ Ort – IMPRESSUM_ANSCHRIFT]';
  const vertreter = env.IMPRESSUM_VERTRETER || '[Vertretungsberechtigte Person – IMPRESSUM_VERTRETER]';
  const mail = env.IMPRESSUM_MAIL || env.MAIL_FROM || 'otto@motto-otto.de';
  const telefon = env.IMPRESSUM_TELEFON || '';
  const ustid = env.IMPRESSUM_USTID || '';
  const register = env.IMPRESSUM_REGISTER || '';

  const shell = (title, body) => `<!doctype html><html lang="de"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${title} – Motto Otto</title><link rel="icon" href="/favicon.png">
<style>body{margin:0;background:#14131a;color:#f4f2f7;font-family:system-ui,sans-serif;font-size:16px;line-height:1.6}.wrap{max-width:760px;margin:0 auto;padding:36px 20px 80px}a{color:#ffc542}h1{font-size:26px}h2{font-size:19px;margin-top:28px}p,li{color:#d8d4e2}.back{color:#8b8598;text-decoration:none;font-size:14px}</style></head>
<body><div class="wrap"><a class="back" href="/">&larr; Motto Otto</a>${body}<p style="margin-top:40px;color:#8b8598;font-size:13px"><a href="/impressum">Impressum</a> · <a href="/datenschutz">Datenschutz</a> · <a href="/nutzungsbedingungen">Nutzungsbedingungen</a></p></div></body></html>`;

  const impressum = shell('Impressum', `
<h1>Impressum</h1>
<p>Angaben gemäß § 5 DDG</p>
<p>${firma}<br>${anschrift}<br>Vertreten durch: ${vertreter}</p>
<p>E-Mail: <a href="mailto:${mail}">${mail}</a>${telefon ? `<br>Telefon: ${telefon}` : ''}</p>
${ustid ? `<p>Umsatzsteuer-Identifikationsnummer gemäß § 27a UStG: ${ustid}</p>` : ''}
${register ? `<p>Registereintrag: ${register}</p>` : ''}
<p>Verantwortlich für den Inhalt nach § 18 Abs. 2 MStV: ${vertreter}, ${anschrift}</p>
<h2>Streitbeilegung</h2>
<p>Die Europäische Kommission stellt eine Plattform zur Online-Streitbeilegung (OS) bereit: <a href="https://ec.europa.eu/consumers/odr/" rel="noopener">https://ec.europa.eu/consumers/odr/</a>. Wir sind nicht bereit oder verpflichtet, an Streitbeilegungsverfahren vor einer Verbraucherschlichtungsstelle teilzunehmen.</p>`);

  const datenschutz = shell('Datenschutzerklärung', `
<h1>Datenschutzerklärung</h1>
<p>Verantwortlicher im Sinne der DSGVO: ${firma}, ${anschrift}, E-Mail <a href="mailto:${mail}">${mail}</a>.</p>
<h2>1. Was Motto Otto tut</h2>
<p>Motto Otto erstellt aus deinen Eingaben (Motto, Namen, Anlass, Farben, optional ein hochgeladenes Logo oder Foto) Design-Vorschläge für Textilien. Dafür werden deine Eingaben an einen KI-Bilddienst übermittelt und die fertigen Druckdateien gespeichert.</p>
<h2>2. Welche Daten wir verarbeiten</h2>
<ul>
<li><b>Eingaben im Konfigurator</b> (Texte, Namen, Farben, Stil) und <b>Uploads</b> (Logos, Fotos). Rechtsgrundlage: Vertragserfüllung bzw. Vertragsanbahnung, Art. 6 Abs. 1 lit. b DSGVO.</li>
<li><b>Erzeugte Designs und Druckdateien</b>, verknüpft mit einer zufälligen Design-Nummer und – falls du dich anmeldest – mit deinem Konto.</li>
<li><b>Konto</b>: E-Mail-Adresse, Anmeldezeitpunkt, Zähler für erstellte Designs und gebuchte Kontingente. Anmeldung erfolgt per E-Mail-Link ohne Passwort.</li>
<li><b>Technische Daten</b>: IP-Adresse, Zeitpunkt, Browser – in Server-Protokollen unseres Hosters, zur Sicherstellung des Betriebs (Art. 6 Abs. 1 lit. f DSGVO).</li>
<li><b>Cookies</b>: ein technisch notwendiges Gast-Cookie (ordnet deine Entwürfe deinem Browser zu) und nach Anmeldung ein Sitzungs-Cookie. Keine Werbe- oder Tracking-Cookies.</li>
</ul>
<h2>3. Empfänger und Auftragsverarbeiter</h2>
<ul>
<li><b>Hosting</b>: Railway Corp., USA (Server-Region EU-West). Auftragsverarbeitung mit Standardvertragsklauseln.</li>
<li><b>KI-Bilderzeugung und Textprüfung</b>: OpenAI, L.L.C., USA. Übermittelt werden die Eingaben des Konfigurators und ggf. das hochgeladene Bild. Daten werden dort nicht zum Training verwendet (API-Nutzung).</li>
<li><b>Recherche zu Mottos</b>: Abfragen bei der Wikipedia-API der Wikimedia Foundation (nur der Motto-Begriff, keine personenbezogenen Daten).</li>
<li><b>Druckdateien-Ablage</b>: Google Drive (Google Ireland Ltd.) zur Übergabe an die Produktion.</li>
<li><b>E-Mail-Versand</b> (Anmelde-Links): Brevo (Sendinblue SAS, Frankreich).</li>
<li><b>Bezahlung</b>: Stripe Payments Europe Ltd., Irland. Zahlungsdaten werden ausschließlich bei Stripe verarbeitet; wir erhalten keine Kartendaten.</li>
</ul>
<h2>4. Speicherdauer</h2>
<p>Uploads und Druckdateien bewahren wir auf, solange sie für Bestellung, Produktion und Nachbestellungen benötigt werden, längstens jedoch drei Jahre nach dem letzten Zugriff. Konten kannst du jederzeit per E-Mail löschen lassen. Server-Protokolle werden nach 30 Tagen gelöscht.</p>
<h2>5. Deine Rechte</h2>
<p>Du hast das Recht auf Auskunft, Berichtigung, Löschung, Einschränkung der Verarbeitung, Datenübertragbarkeit und Widerspruch (Art. 15–21 DSGVO) sowie auf Beschwerde bei einer Datenschutz-Aufsichtsbehörde. Schreib uns an <a href="mailto:${mail}">${mail}</a>.</p>
<h2>6. Hochgeladene Bilder</h2>
<p>Lade nur Logos und Fotos hoch, an denen du die nötigen Rechte hast. Fotos, auf denen Personen erkennbar sind, werden von der KI nur stilisiert nachgezeichnet; die Originale werden nicht veröffentlicht.</p>
<p style="color:#8b8598;font-size:13px">Stand: September 2026</p>`);

  const agb = shell('Nutzungsbedingungen', `
<h1>Nutzungsbedingungen</h1>
<p>Anbieter: ${firma}, ${anschrift}.</p>
<h2>1. Leistung</h2>
<p>Motto Otto erzeugt auf Basis deiner Eingaben Design-Vorschläge und Druckdateien für Textilien. Die Vorschau ist ein Mockup; Farben und Größen auf dem echten Textil können leicht abweichen.</p>
<h2>2. Kontingente und Preise</h2>
<p>Die ersten fünf Designs je Konto sind kostenfrei. Jedes weitere Design kostet 1,00 € inkl. USt. Mitgliedschaften (10 €/Monat für 100 Designs, 29 €/Monat für 400 Designs) sind monatlich kündbar und verlängern sich automatisch um einen Monat, sofern nicht vor Ablauf gekündigt wird. Nicht genutzte Designs verfallen am Monatsende.</p>
<h2>3. Rechte an den Designs</h2>
<p>Du erhältst an den für dich erzeugten Designs ein einfaches, zeitlich unbegrenztes Nutzungsrecht für Textildruck und eigene Zwecke. Von dir hochgeladene Logos und Bilder bleiben dein Eigentum; du versicherst, die nötigen Rechte daran zu haben.</p>
<h2>4. Unzulässige Inhalte</h2>
<p>Unzulässig sind Eingaben und Uploads, die Rechte Dritter verletzen, beleidigend, volksverhetzend oder sonst rechtswidrig sind. Solche Aufträge können ohne Erstattung abgebrochen werden.</p>
<h2>5. Widerruf</h2>
<p>Bei digitalen Inhalten, die nach deinen Vorgaben individuell erzeugt werden, erlischt das Widerrufsrecht mit Beginn der Erzeugung, wenn du dem ausdrücklich zugestimmt und deine Kenntnis vom Erlöschen bestätigt hast (§ 356 Abs. 5 BGB).</p>
<h2>6. Haftung</h2>
<p>Wir haften unbeschränkt bei Vorsatz und grober Fahrlässigkeit sowie nach dem Produkthaftungsgesetz. Bei einfacher Fahrlässigkeit haften wir nur bei Verletzung wesentlicher Vertragspflichten, begrenzt auf den vorhersehbaren, vertragstypischen Schaden.</p>
<p style="color:#8b8598;font-size:13px">Stand: September 2026</p>`);

  return { impressum, datenschutz, agb };
}
