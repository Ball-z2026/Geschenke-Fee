import fs from 'node:fs/promises';
import path from 'node:path';

// ---------- Gemeinsame Druckregeln, haengen an JEDEM Master-Prompt ----------
const RULES_COMMON_1 = 'Print rules: artwork fully isolated on a plain empty background with clean alpha edges, no checkerboard. Bold, clearly separated color fields, no gradients fading out.';
const RULES_COMMON_2 = 'All text readable at A4 print size and spelled exactly as given. Portrait, centered, the whole artwork fits inside the canvas with an empty margin of at least 6 percent on every side - nothing touches or crosses the edges. Never: coats of arms, club or brand logos, real trademarks, recognizable people, cars, or words other than the ones specified.';
export const PRINT_RULES = [
  RULES_COMMON_1,
  'The print goes on BLACK or dark shirts: all lettering light (cream, off-white, gold, bright colors) with a dark outline, dark shapes with a light outline; never dark lettering without a light outline. No large flat white plates or panels.',
  RULES_COMMON_2
].join('\n');
export const PRINT_RULES_LIGHT = [
  RULES_COMMON_1,
  'The print goes on WHITE or light shirts: all lettering in dark or strong saturated colors (black, navy, deep red, forest green) with a thin light or contrasting outline; no white or cream lettering and no large white fills - white would vanish on the shirt. Light shapes always get a dark outline.',
  RULES_COMMON_2
].join('\n');

// ---------- Text saeubern ----------
const BLOCKLIST = /(nazi|hitler|afd|nsdap|hakenkreuz|fick|hure|wichser|nutte|schlampe)/i;

// Erlaubt sind Buchstaben, Zahlen, Leerzeichen und . , ! ? & ' - + / ( ) : Alles andere (Emojis, Sonderzeichen)
// wird stillschweigend entfernt - der Kunde bekommt einen Hinweis, was weggelassen wurde.
export const ALLOWED_CHARS = /[^\p{L}\p{N} .,!?&'’\-–+/():#]/gu;
export function stripChars(value) {
  return String(value || '').replace(ALLOWED_CHARS, '').replace(/\s+/g, ' ').trim();
}
export function cleanValue(value, max) {
  if (value === undefined || value === null) return '';
  const t = stripChars(value).slice(0, Math.min(+max || 40, 120));
  if (!t) return '';
  if (BLOCKLIST.test(t)) return null;
  return t;
}

export function slugify(s) {
  return String(s || '').toLowerCase()
    .replace(/ä/g, 'ae').replace(/ö/g, 'oe').replace(/ü/g, 'ue').replace(/ß/g, 'ss')
    .replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 40);
}

// ---------- Prompt bauen ----------
// {feld}      wird durch den Kundenwert ersetzt
// [[ ... ]]   faellt komplett weg, wenn ein darin genanntes Feld leer ist
export function fillPrompt(template, values) {
  let out = String(template || '');

  out = out.replace(/\[\[([\s\S]*?)\]\]/g, (whole, inner) => {
    const keys = [...inner.matchAll(/\{([a-zA-Z0-9_]+)\}/g)].map(m => m[1]);
    for (const k of keys) if (!values[k]) return '';
    return inner;
  });

  out = out.replace(/\{([a-zA-Z0-9_]+)\}/g, (whole, key) => values[key] || '');
  return out.replace(/[ \t]{2,}/g, ' ').replace(/\n{3,}/g, '\n\n').trim();
}

// ---------- Stile, die der Kunde auf jeder Motto-Seite waehlen kann ----------
// Der gewaehlte Stil ueberschreibt die Stilzeile des Master-Prompts, die Komposition bleibt.
export const STYLES = {
  standard:  { label: 'Wie vorgesehen', desc: 'So, wie das Motto gedacht ist', text: '' },
  streetart: { label: 'Street Art', desc: 'Graffiti, Spraydose, Drips',
    text: 'Authentic graffiti piece sprayed by a street-art writer: wildstyle or bubble lettering with fat, overlapping letter forms, 3D blocks and highlights; visible spray-paint texture with soft overspray edges, paint drips running down from the letters, splatter dots and stencil elements; a few small tags scribbled as accents. Loud high-contrast colors: neon pink, cyan, lime, orange and chrome silver, all outlined in black. Everything - every word, every ornament - must look sprayed on a wall, never like a clean vector.' },
  meisterwerk: { label: 'Meisterwerk', desc: 'Edel, Gold, wie ein altes Gemälde',
    text: 'Fine-art masterpiece in the manner of an old-master oil painting: visible painterly brushwork and glazed layers, chiaroscuro lighting with deep shadows and warm candle-like highlights, ornate baroque gold flourishes, filigree scrollwork and a gilded frame element. Rich jewel tones: burgundy, deep green, ultramarine, gold leaf. Lettering elegant engraved serif or blackletter, as if carved into a gold plaque. The whole piece must look painted by hand, luxurious and museum-like, never flat or cartoonish.' },
  minimal: { label: 'Minimalistisch', desc: 'Klare Linien, wenig Farbe',
    text: 'Strict minimalist design: the motif reduced to one continuous mono-line drawing or a few clean geometric shapes; at most two colors in total (off-white plus one accent); generous empty space; no shading, no texture, no ornaments, no outlines around the text. Lettering in a light, widely spaced geometric sans-serif. Calm, modern Scandinavian poster feel - if in doubt, leave it out.' },
  popart: { label: 'Pop-Art', desc: 'Comic-Raster, knallige Farben',
    text: 'Genuine 1960s pop-art print in the spirit of Lichtenstein and Warhol: coarse Ben-Day halftone dot fills, thick uniform black outlines, flat primary colors (lemon yellow, tomato red, cyan, magenta), bold speech-bubble or onomatopoeia lettering, deliberate slight misregistration of the color layers, repeated elements in different color combinations. Loud, graphic, silkscreen look.' },
  vintage: { label: 'Vintage', desc: 'Retro-Look, abgenutzt',
    text: 'Authentic vintage screen print from the 1970s: heavily distressed, cracked and faded ink, grainy worn texture, slightly misregistered color layers, muted sun-bleached palette (cream, mustard, rust, olive, dusty teal, faded brown), retro badge typography with arched lettering, thick-thin serifs and rounded 70s scripts, sunset stripes or a simple emblem shape. Must look like a shirt that has been washed a hundred times.' },
  tattoo: { label: 'Tattoo', desc: 'Old-School, dicke Linien',
    text: 'Drawn by a traditional American old-school tattoo artist as a flash-sheet design: bold, uniform black outlines, solid black shading with whip-shading and stippling, a limited flat palette of red, green, yellow and cream, classic tattoo motifs as accents (roses, daggers, swallows, anchors, banners with script lettering, stars). Lettering in tattoo script or bold block letters inside a ribbon. Must read as an actual tattoo drawing, not a logo.' },
  comic: { label: 'Comic', desc: 'Cartoon, lustig, bunt',
    text: 'Hand-drawn comic-book illustration: visible ink linework of varying weight, cross-hatching and spot blacks for shading, flat cel-shaded colors, exaggerated funny cartoon figures with big expressions, motion lines, impact bursts, a hand-lettered comic headline with a drop shadow. Must look drawn with pen and ink by a comic artist, not like a clean vector logo.' },
  japan: { label: 'Japan', desc: 'Wellen, Kirschblüten, Pinselschrift',
    text: 'Japanese ukiyo-e woodblock-print style as by Hokusai: flat color areas with visible woodgrain texture, flowing stylized waves with foam fingers, cloud bands, cherry blossoms, a red sun disc, koi or crane accents, bold black key-block outlines. Palette of indigo, vermilion red, cream and black. Lettering with the character of brush calligraphy strokes. Must look like a real woodblock print.' },
  college: { label: 'College', desc: 'Varsity, Sport, Streifen',
    text: 'Classic American college varsity print: big arched block letters with a contrasting inline stroke and drop shadow, a large number or year, chenille-patch texture feel, chevrons and stripes, laurel or pennant accents, a mascot-style silhouette. Two school colors plus cream. Clean, sporty, athletic-department look.' },
  neon: { label: 'Neon', desc: 'Synthwave, Glühen, 80er',
    text: '1980s synthwave neon style: glowing neon tube lettering with a visible soft glow and chrome highlights, a striped retro sun, a perspective grid horizon, palm silhouettes and laser lines. Palette of hot pink, electric purple, cyan and deep midnight blue with cream highlights. Everything looks lit from within, like a neon sign at night.' }
};
export const STYLE_KEYS = Object.keys(STYLES);

// Backend-Aenderungen an den Stilen (storage/styles.json) werden hier eingespielt
export function applyStyleOverrides(over) {
  for (const k of STYLE_KEYS) {
    const o = over && over[k];
    if (!o) continue;
    if (typeof o.label === 'string' && o.label.trim()) STYLES[k].label = o.label.trim().slice(0, 30);
    if (typeof o.desc === 'string') STYLES[k].desc = o.desc.trim().slice(0, 60);
    if (typeof o.text === 'string' && k !== 'standard') STYLES[k].text = o.text.trim().slice(0, 900);
    STYLES[k].off = !!o.off;
  }
}
export function stylesForAdmin() {
  return STYLE_KEYS.map(k => ({ key: k, label: STYLES[k].label, desc: STYLES[k].desc, text: STYLES[k].text, off: !!STYLES[k].off }));
}

// ---------- Unikat-Variation: jedes Teil bekommt eine eigene Mischung ----------
// Der Master-Prompt legt Aufbau und Texte fest; diese Zutaten werden je Auftrag zufaellig gezogen,
// damit nie zweimal dasselbe Motiv mit nur anderem Namen entsteht.
export const VARIETY = {
  layout: [
    'headline arched over the top, footer text on a straight banner',
    'all text stacked in a tall centered column, main motif behind the text',
    'headline on a waving ribbon, main motif above it, secondary text in a small badge',
    'asymmetric composition, main motif slightly off-center, text following its edge',
    'circular badge layout, text running along the circle',
    'diamond-shaped emblem with the main motif inside and text on the corners',
    'shield-shaped crest with the text in a band across the middle',
    'headline huge and dominant, motif small underneath like a signature'
  ],
  ornament: [
    'a few scattered stars and sparkles',
    'sunburst rays behind the motif',
    'laurel branches at the sides',
    'halftone dot shading in the background shapes',
    'thin double-line frame with corner flourishes',
    'paint splatter and ink drips as accents',
    'small geometric confetti pieces',
    'a subtle worn, distressed print texture',
    'no ornaments at all, clean and reduced'
  ],
  lettering: [
    'heavy slab-serif block lettering',
    'condensed tall sans-serif lettering',
    'varsity-style college lettering with an inline stroke',
    'brush script for the headline, small caps for the rest',
    'rounded bubbly lettering with a thick outline',
    'classic engraved serif lettering',
    'stencil lettering with cut gaps',
    'hand-drawn sign-painter lettering'
  ]
};
const pick = (arr) => arr[Math.floor(Math.random() * arr.length)];

export function pickVariation(motto, opts = {}) {
  if (motto && motto.vary === false) return null;
  const own = String((motto && motto.variations) || '').split('\n').map(l => l.trim()).filter(Boolean);
  const parts = [];
  if (own.length) parts.push(pick(own));
  parts.push('layout: ' + pick(VARIETY.layout));
  // Bei gewaehltem Kunststil bestimmen Schmuck und Schrift der Stil, nicht der Zufall
  if (!opts.styled) {
    parts.push('ornaments: ' + pick(VARIETY.ornament));
    parts.push('lettering: ' + pick(VARIETY.lettering));
  }
  return parts.join('; ');
}

export function buildPrompt(motto, values, extra = {}) {
  // Felder "je Person" werden nicht gemalt: jede Zeile, die den Platzhalter nennt, faellt weg
  let template = String(motto.prompt || '');
  for (const f of (motto.fields || [])) {
    if (!f.personal) continue;
    const re = new RegExp('\\{' + f.key + '\\}');
    template = template.split('\n').filter(l => !re.test(l)).join('\n');
  }
  let body = fillPrompt(template, values);
  const style = STYLES[extra.style] && STYLES[extra.style].text;
  if (style) body = body.replace(/^\s*Style:.*$/gim, '').replace(/\n{3,}/g, '\n\n').trim();
  const colors = extra.colors ? String(extra.colors).trim() : '';
  const parts = [body];
  if (extra.research) parts.push(extra.research);
  if (style) parts.push(`ART STYLE (mandatory, chosen by the customer): ${style}\nRender the ENTIRE artwork - every motif, every ornament and every letter - in exactly this technique. Do not mix in any other style. Keep the composition, all texts and the empty logo area as described above.`);
  if (extra.logoColors) parts.push(`A real emblem (the customer's own logo) is placed into the reserved empty area afterwards. Its main colors are: ${extra.logoColors}. Pick up these colors in the ribbons, outlines and accents of the design so the emblem looks like a natural part of the artwork. The reserved area itself stays completely empty: no disc, no plate, no circle, no shield, no shape of any kind there - only transparent background.`);
  if (colors) parts.push(`Color scheme chosen by the customer - make these the dominant colors of the whole design, harmonious and print-safe: ${colors}. ${extra.textile === 'hell' ? 'Keep lettering dark with a light outline so it stays readable on a white shirt.' : 'Keep lettering light with dark outlines so it stays readable on a black shirt.'}`);
  if (extra.nameZone) parts.push(extra.nameZone);
  if (extra.variation) parts.push(`This piece is a one-of-a-kind design - every design of this series must look clearly different. Use this variation for this piece (keep all texts, the empty area for the logo and the print rules): ${extra.variation}.`);
  parts.push(extra.textile === 'hell' ? PRINT_RULES_LIGHT : PRINT_RULES);
  // Bildmodell erlaubt 4000 Zeichen: notfalls Recherche und Stil kuerzen
  let out = parts.filter(Boolean).join('\n\n');
  const LIMIT = 3900;
  if (out.length > LIMIT && extra.research) {
    const i = parts.indexOf(extra.research);
    parts[i] = extra.research.slice(0, Math.max(400, extra.research.length - (out.length - LIMIT) - 50));
    out = parts.filter(Boolean).join('\n\n');
  }
  if (out.length > LIMIT && style) {
    const i = parts.findIndex(p => p.startsWith('ART STYLE'));
    parts[i] = parts[i].slice(0, Math.max(300, parts[i].length - (out.length - LIMIT) - 20));
    out = parts.filter(Boolean).join('\n\n');
  }
  if (out.length > LIMIT) out = out.slice(0, LIMIT);
  return out;
}

// Welche Texte muessen nachher wirklich im Bild stehen?
export function printedTexts(motto, values) {
  return (motto.fields || [])
    .filter(f => f.printed !== false && !f.personal && (f.type === 'text' || f.type === 'select'))
    .map(f => values[f.key])
    .filter(Boolean);
}

// ---------- Motto pruefen ----------
const UPLOAD_MODES = ['off', 'exact', 'reference'];
const FIELD_TYPES = ['text', 'select'];
const PLACES = ['oben', 'mitte', 'unten'];

export function sanitizeMotto(input) {
  const m = input || {};
  const name = String(m.name || '').trim().slice(0, 60);
  if (!name) throw new Error('Name fehlt');
  const prompt = String(m.prompt || '').trim();
  if (prompt.length < 30) throw new Error('Master-Prompt ist zu kurz');

  const slug = slugify(m.slug || name);
  if (!slug) throw new Error('Kuerzel laesst sich nicht bilden');

  const seen = {};
  const fields = (Array.isArray(m.fields) ? m.fields : []).slice(0, 12).map((f, i) => {
    const key = slugify(f.key || f.label || ('feld' + (i + 1))).replace(/-/g, '_') || ('feld' + (i + 1));
    if (seen[key]) throw new Error('Zwei Felder heissen gleich: ' + key);
    seen[key] = 1;
    const type = FIELD_TYPES.includes(f.type) ? f.type : 'text';
    return {
      key,
      label: String(f.label || key).slice(0, 60),
      type,
      required: !!f.required,
      printed: f.printed !== false,
      personal: !!f.personal,
      max: Math.min(Math.max(+f.max || 40, 1), 120),
      placeholder: String(f.placeholder || '').slice(0, 60),
      hint: String(f.hint || '').slice(0, 140),
      options: type === 'select'
        ? (Array.isArray(f.options) ? f.options : []).map(o => String(o).slice(0, 60)).filter(Boolean).slice(0, 24)
        : []
    };
  });

  if (fields.filter(f => f.personal).length > 1) throw new Error('Nur ein Feld darf "je Person" sein');
  const up = m.upload || {};
  const mode = UPLOAD_MODES.includes(up.mode) ? up.mode : 'off';

  return {
    slug,
    name,
    active: m.active !== false,
    order: Math.min(Math.max(+m.order || 100, 0), 9999),
    intro: String(m.intro || '').slice(0, 400),
    headline: String(m.headline || '').slice(0, 90),
    text: String(m.text || '').slice(0, 1200),
    sample: String(m.sample || '').replace(/[^A-Za-z0-9_-]/g, '').slice(0, 40),
    accent: /^#[0-9a-fA-F]{6}$/.test(String(m.accent || '')) ? String(m.accent) : '#ffc542',
    size: ['1024x1536', '1024x1024', '1536x1024'].includes(m.size) ? m.size : '1024x1536',
    styleChoice: m.styleChoice !== false,
    colorChoice: m.colorChoice !== false,
    vary: m.vary !== false,
    variations: String(m.variations || '').slice(0, 2000),
    research: !!m.research,
    researchField: slugify(m.researchField || '').replace(/-/g, '_'),
    suggestions: String(m.suggestions || '').slice(0, 3000),
    nameZone: ['oben', 'unten'].includes(m.nameZone) ? m.nameZone : 'unten',
    nameFont: ['rund', 'schmal', 'serif'].includes(m.nameFont) ? m.nameFont : 'rund',
    fields,
    upload: {
      mode,
      label: String(up.label || 'Logo oder Foto').slice(0, 60),
      hint: String(up.hint || '').slice(0, 200),
      required: !!up.required,
      place: PLACES.includes(up.place) ? up.place : 'unten',
      widthPct: Math.min(Math.max(+up.widthPct || 38, 8), 90)
    },
    prompt,
    updated: new Date().toISOString()
  };
}

// ---------- Ablage auf der Platte ----------
export function mottoStore(dir) {
  const file = (slug) => path.join(dir, slug + '.json');

  return {
    async all() {
      let names = [];
      try { names = await fs.readdir(dir); } catch (e) { return []; }
      const out = [];
      for (const n of names) {
        if (!n.endsWith('.json')) continue;
        try { out.push(JSON.parse(await fs.readFile(path.join(dir, n), 'utf8'))); } catch (e) { /* kaputte Datei ueberspringen */ }
      }
      return out.sort((a, b) => (a.order - b.order) || String(a.name).localeCompare(String(b.name)));
    },
    async get(slug) {
      try { return JSON.parse(await fs.readFile(file(slugify(slug)), 'utf8')); } catch (e) { return null; }
    },
    async save(motto) {
      const clean = sanitizeMotto(motto);
      await fs.writeFile(file(clean.slug), JSON.stringify(clean, null, 2));
      return clean;
    },
    async remove(slug) {
      try { await fs.rm(file(slugify(slug)), { force: true }); return true; } catch (e) { return false; }
    }
  };
}

// Was der Kunde sieht - ohne Master-Prompt.
export function publicView(m) {
  return {
    slug: m.slug, name: m.name, intro: m.intro, headline: m.headline || '', text: m.text || '', accent: m.accent || '#ffc542', hasSample: !!m.sample,
    styleChoice: m.styleChoice !== false, colorChoice: m.colorChoice !== false,
    nameZone: m.nameZone || 'unten',
    research: !!m.research, researchField: m.researchField || '',
    suggestions: String(m.suggestions || '').split('\n').map(l => l.trim()).filter(Boolean).slice(0, 60),
    styles: STYLE_KEYS.filter(k => !STYLES[k].off).map(k => ({ key: k, label: STYLES[k].label, desc: STYLES[k].desc })),
    fields: m.fields, upload: { mode: m.upload.mode, label: m.upload.label, hint: m.upload.hint, required: m.upload.required }
  };
}
